<span class="d-flex w-50">
    <input wire:model.live="search" class="form-control me-2" type="text" placeholder="Search" aria-label="Search">    
        <!--[if BLOCK]><![endif]--><?php if($this->get_result != NULL): ?>
        <div class="search-items w-25">
            <section>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->get_result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p>
                    <a href="<?php echo e(url('product/'.$key->id)); ?>"><?php echo e($key->product_name); ?></a>
                </p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </section>
        </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</span>
<?php /**PATH C:\xampp\htdocs\Ecommerce\resources\views/livewire/search.blade.php ENDPATH**/ ?>