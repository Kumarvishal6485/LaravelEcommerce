<div class="row p-2 nav-bar">
            <div class="col-lg-2 col-md-2 col-sm-2">
                <span class="p-3"><i class="header-text">Admin</i></span>
            </div>
            <div class="col-lg-8 col-md-6 col-sm-4"></div>
            <div class="col-lg-2 col-md-4 col-sm-6">
                <?php if(session()->has('username')): ?>
                    <a href="<?php echo e(url('admin/logout')); ?>" class="btn btn-success">Logout</a>
                <?php else: ?>
                    <a href="<?php echo e(url('login')); ?>" class="btn btn-success">Login</a>
                <?php endif; ?>
            </div>
        </div><?php /**PATH C:\xampp\htdocs\Ecommerce\resources\views/components/admin_header.blade.php ENDPATH**/ ?>