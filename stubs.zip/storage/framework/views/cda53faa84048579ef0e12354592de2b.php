<div class="row" id="filter-data">
  <!-- Shop Sidebar Start -->
  <div class="col-lg-2 col-md-12 border mt-3 p-2">
    <!-- Price Start -->
    <center><h4>Filter By</h4></center>
    <div class="">
      <div class="accordion" id="accordionExample">
        <div class="accordion-item">
          <h2 class="accordion-header" id="headingOne">
            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne"
              aria-expanded="true" aria-controls="collapseOne">
              Category
            </button>
          </h2>
          <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne"
            data-bs-parent="#accordionExample">
            <div class="accordion-body">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form>
                    <input type="radio" value_id = "<?php echo e($category->id); ?>" wire:click="getcategories(<?php echo e($category->id); ?>)"> <?php echo e($category->category); ?> <br>
                </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
          </div>
        </div>
      </div>
      <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="accordion" id="accordionExample">
        <div class="accordion-item">
          <h2 class="accordion-header" id="headingOne">
            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne"
              aria-expanded="true" aria-controls="collapseOne" wire:click="getvalues(<?php echo e($attribute->id); ?>)" wire:key="<?php echo e($attribute->id); ?>">
              <?php echo e(ucfirst($attribute->attribute)); ?>

            </button>
          </h2>
          <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne"
            data-bs-parent="#accordionExample">
            <div class="accordion-body">
                <form>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input type="radio" value_id = "<?php echo e($attribute->id); ?>" wire:click="attribute_value_product(<?php echo e($attribute->id); ?>)"> <?php echo e($attribute->value); ?> <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </form>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </div>
  </div>
  <!-- Shop Sidebar End -->
  <!-- Shop Product Start -->
  <div class="col-lg-10 col-md-12">
    <div class="row pb-3">
      <div class="row mt-2 p-4">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-4 col-sm-12" wire:ignore wire:key="product-<?php echo e($key->id); ?>">
          <div class="card mb-3" style="width: 18rem;">
            <a href="<?php echo e(url('product/'.$key->id)); ?>">
              <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('image', ['pid' => $key->id]);

$__html = app('livewire')->mount($__name, $__params, $key->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </a>
            <div class="card-body">
              <h5 class="card-title"><?php echo e($key->product_name); ?></h5>
              <div class="container">
                <div class="row mb-3">
                  <div class="col-lg-7 col-md-7 col-sm-7">
                    ₨ <?php echo e($key->price); ?>&nbsp;<small><del>₨ <?php echo e($key->cost); ?></del></small>
                  </div>
                  <div class="col-lg-5 col-md-5 col-sm-5">
                    <a class="p-2 mb-2 buy-btn" href="buy/<?php echo e($key->id); ?>">Buy Now</a>
                  </div>
                </div>
                <div class="row">
                  <div class="col-lg-4 col-md-4 col-sm-4">
                    <i class="far fa-eye fa-2x" id="<?php echo e($key->id); ?>"></i>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-4">
                    <i class="far fa-heart fa-2x mr-2" wire:click.prevent="add_to_wishlist(<?php echo e($key->id); ?>)"></i>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-4">
                    <i class="fas fa-cart-plus fa-2x mr-2" wire:click.prevent="add_to_cart(<?php echo e($key->id); ?>)"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
      </div>
    </div>
  </div>
  <!-- Shop Product End -->
</div><?php /**PATH C:\xampp\htdocs\Ecommerce\resources\views/livewire/filters.blade.php ENDPATH**/ ?>