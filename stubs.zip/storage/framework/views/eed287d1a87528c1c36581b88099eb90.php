<div class="row mt-2 p-4">
  <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-3 col-md-4 col-sm-12" wire:ignore wire:key="product-<?php echo e($key->id); ?>">
        <div class="card mb-3" style="width: 18rem;">
          <a href="<?php echo e(url('product/'.$key->id)); ?>"><?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('image', ['pid' => $key->id]);

$__html = app('livewire')->mount($__name, $__params, $key->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?></a>
          <div class="card-body">
            <h5 class="card-title"><?php echo e($key->product_name); ?></h5>
            <div class="container">
              <div class="row mb-3">
                <div class="col-lg-7 col-md-7 col-sm-7">
                  ₨ <?php echo e($key->price); ?>&nbsp;<small><del>₨ <?php echo e($key->cost); ?></del></small>
                </div>
                <div class="col-lg-5 col-md-5 col-sm-5">
                  <a class="p-2 mb-2 buy-btn" href="buy/<?php echo e($key->id); ?>">Buy Now</a>
                </div>
              </div>
              <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-4">
                  <i class="far fa-eye fa-2x"  id="<?php echo e($key->id); ?>"></i>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4">
                  <i class="far fa-heart fa-2x mr-2" wire:click.prevent="add_to_wishlist(<?php echo e($key->id); ?>)"></i>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4">
                  <i class="fas fa-cart-plus fa-2x mr-2" wire:click.prevent="add_to_cart(<?php echo e($key->id); ?>)"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH C:\xampp\htdocs\Ecommerce\resources\views/livewire/products.blade.php ENDPATH**/ ?>