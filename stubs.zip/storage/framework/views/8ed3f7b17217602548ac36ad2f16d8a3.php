<div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree"
  data-bs-parent="#accordionExample">
  <div class="accordion-body">
    <form class="form-inline review-form" wire:submit="submit_review_data(<?php echo e(Request()->pid); ?>)" >
      <?php echo e(@csrf_field()); ?>

      <input type="hidden" wire:model="<?php echo e(Request()->pid); ?>">
      <div class="form-group mb-2">
        <input type="text" class="form-control" id="inputPassword2" wire:model="review_text" placeholder="Write Review here">
      </div>
      <div class="form-group mb-2">
        <input type="file" class="form-control-file" id="exampleFormControlFile1" wire:model="image[]" multiple>
      </div>
      <button type="submit" class="btn btn-success mb-2" >Add Review</button>
    </form>
    <!--[if BLOCK]><![endif]--><?php if(sizeof($data) > 0): ?>
    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="product-review">
        <section class="user-details">
          <img src="<?php echo e(asset('storage/site_images_icons/user_image.jpg')); ?>" alt="" ><span>User</span>
        </section>
        <section class="user-review">
          <span><?php echo e($obj->review_text); ?></span>
          <!-- <img src="img.jpg" alt=""> -->
        </section>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    <?php else: ?>
    <div class="product-review">
        <section class="user-review">
          <span>No Review Exist For this Product</span>
        </section>
      </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
  </div>
</div><?php /**PATH C:\xampp\htdocs\Ecommerce\resources\views/livewire/review.blade.php ENDPATH**/ ?>