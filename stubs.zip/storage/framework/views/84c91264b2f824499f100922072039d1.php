<div class="row mt-2">
  <div class="col-lg-8 col-md-12 col-sm-12">
    <table class="table table-bordered">
      <thead>
        <tr>
          <th scope="col">S.No</th>
          <th scope="col">Product</th>
          <th scope="col">Price</th>
          <th scope="col" colspan="2">Quantity</th>
        </tr>
      </thead>
      <tbody>
        <!--[if BLOCK]><![endif]--><?php if($data != NULL && count($data)): ?>
        <?php $i=0;?>
        <?php
        $product_name = array();
        $quantity = array();
        $price = array();
        ?>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $product_name[$product->id] = $product->product_name;
        $price[$product->id] = $product->price;
        ?>
        <tr>
          <!--[if BLOCK]><![endif]--><?php if(session()->has('user_id')): ?>
          <?php
          $quantity[$product->id] = $product->quantity;
          ?>
          <th>
            <input class="form-check-input" type="checkbox" wire:key="<?php echo e($product->id); ?>" checked>
            &nbsp;<?php echo e(++$i); ?>

          </th>
          <td><a href="<?php echo e(url('/product/'.$product->id)); ?>"><?php echo e($product->product_name); ?></a></td>
          <?php elseif(session()->has('cart')): ?>
          <th>
            <input class="form-check-input" type="checkbox" wire:key="<?php echo e($product->id); ?>" checked>
            &nbsp;<?php echo e(++$i); ?>

          </th>
          <td><a href="<?php echo e(url('/product/'.$product->id)); ?>"><?php echo e($product->product_name); ?></a></td>
          <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
          <td>₨&nbsp;<?php echo e($product->price); ?></td>
          <!--[if BLOCK]><![endif]--><?php if(session()->has('user_id')): ?>
          <td>
            <div class="quantity" wire:key="<?php echo e($product->id); ?>">
              <span class="minus" wire:click="dec_quantity(<?php echo e($product->id); ?>,<?php echo e($product->quantity); ?>)">-</span>
              <span class="num"><?php echo e($product->quantity); ?></span>
              <span class="plus" wire:click="inc_quantity(<?php echo e($product->id); ?>,<?php echo e($product->quantity); ?>)">+</span>
            </div>
          </td>
          <td><a wire:click.prevent="remove_product(<?php echo e($product->id); ?>)"><i class="fa fa-trash"></i></a></td>
          <?php elseif(session()->has('cart')): ?>
            <?php
              $quantity[$product->id] = $cart[$product->id];
            ?>
          <td>
            <div class="quantity" wire:key="$product->id" >
              <span class="minus" wire:click="dec_quantity(<?php echo e($product->id); ?>,<?php echo $cart[$product->id]?>)">-</span>
              <span class="num"><?php echo e($cart[$product->id]); ?></span>
              <span class="plus" wire:click="inc_quantity(<?php echo e($product->id); ?>,<?php echo $cart[$product->id]?>)">+</span>
            </div>
          </td>
          <td><a wire:click.prevent="remove_product(<?php echo e($product->id); ?>)"><i class="fa fa-trash"></i></a></td>
          <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        <?php else: ?>
        <tr>
          <td colspan="4">
            <center>Cart is Empty</center>
          </td>
        </tr>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
      </tbody>
    </table>
  </div>

  <div class="col-lg-4 col-md-12 col-sm-12">
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>Summary</th>
        </tr>
      </thead>
      <tbody>
        <?php 
            $total = 0;
        ?>
        <!--[if BLOCK]><![endif]--><?php if($data != NULL && count($data)): ?>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $product_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $total = $total + ($price[$key] * $quantity[$key]);
        ?>
        <tr>
          <td><?php echo e($value); ?> &nbsp; <span><?php echo e($price[$key]); ?> * <?php echo e($quantity[$key]); ?></span></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <tr>
          <?php
            Request()->session()->put('amount',$total);
          ?>
          <td>Total <span><?php echo e($total); ?></span></td>
        </tr>
        <tr>
          <td>
              <!--[if BLOCK]><![endif]--><?php if($total != 0): ?>
                <a class="btn btn-success w-100" href="<?php echo e(url('checkout')); ?>">Checkout</a>
              <?php else: ?>
                <a class="btn btn-success w-100">Checkout</a>
              <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </td>
        </tr>
      </tbody>
    </table>
  </div>
</div><?php /**PATH C:\xampp\htdocs\Ecommerce\resources\views/livewire/cart.blade.php ENDPATH**/ ?>