<div>
    <div class="row m-5">
      <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-lg-3 mt-5">
        <!--[if BLOCK]><![endif]--><?php if($type == "category"): ?>
        <a href="<?php echo e(url('sub_categories/'.$key->id)); ?>">
          <div class="card" style="width: 15rem;">
          <div class="card-body category">  
          <img src="storage/<?php echo e($key->image); ?>" class="category-images">
            <p><?php echo e($key->category); ?></p>
          </div>
        </div>
        <?php else: ?>
          <a href="<?php echo e(url('products/'.$key->id.'/'.$id)); ?>">
            <div class="card" style="width: 15rem;">
              <div class="card-body category">  
                <img src="../storage/sub_category/<?php echo e($key->image); ?>" class="category-images">
                <p><?php echo e($key->sub_category); ?></p>
              </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </a>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->  
</div><?php /**PATH C:\xampp\htdocs\Ecommerce\resources\views/livewire/category.blade.php ENDPATH**/ ?>