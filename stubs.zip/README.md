<p align="center"><a href="https://laravel.com" target="_blank"><img src="https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg" width="400" alt="Laravel Logo"></a></p>

<p align="center">
</p>
#Ecommerce Project
-Working on a Complete laravel project that comprised of admin panel and the user website .
-In admin panel implemented the category CRUD , Sub category CRUD , Product and the Users CRUD , that involves the server side processing and generating the dynamic functionality to the website using jquery-ajax.
-implemented the export library of laravel for exporting the data in the form of Excel Sheets using matwebsite-excel-export.
-implemented the google login using laravel Socialite
