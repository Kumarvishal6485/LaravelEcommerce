<!DOCTYPE html>
<html lang="en">
<x-header />

<body>
  <x-navbar />
  <div class="container-fluid">
    <div class="row mt-5">
      <div class="col-lg-12 col-md-12 col-sm-12">
        <h3 class="p-4">Cart</h3>
      </div>
    </div>
    <livewire:cart/>
  </div>
  <x-footer />
</body>

</html>