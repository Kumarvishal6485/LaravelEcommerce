<!DOCTYPE html>
<html lang="en">
<head>
<x-header/>
</head>
<body>
    <div class="container-fluid">
        <x-admin_header/>
        <div class="row h-25">
            <x-sidebar/>
            <div class="col-lg-10 col-md-10">
                
            </div>
        </div>
    </div>
</body>
</html>