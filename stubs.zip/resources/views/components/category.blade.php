<div>
  <div class="row m-5">
    <div class="col-lg-3">
      <a href="categories">
        <div class="card" style="width: 15rem;">
          <div class="card-body category">
            <i class="fas fa-laptop fa-3x"></i>
            <p>Laptop</p>
          </div>
        </div>
      </a>
    </div>
    <div class="col-lg-3">
      <a href="categories">
        <div class="card" style="width: 15rem;">
          <div class="card-body category">
            <i class="fas fa-mobile-screen-button fa-3x"></i>
            <p>Mobile</p>
          </div>
        </div>
      </a>
    </div>
    <div class="col-lg-3">
      <a href="categories">
        <div class="card" style="width: 15rem;">
          <div class="card-body category">
            <i class="fas fa-headphones fa-3x"></i>
            <p>Headphone</p>
          </div>
        </div>
      </a>
    </div>
    <div class="col-lg-3">
      <a href="categories">
        <div class="card" style="width: 15rem;">
          <div class="card-body category">
            <i class="fas fa-briefcase fa-3x"></i>
            <p>Bag</p>
          </div>
        </div>
      </a>
    </div>
  </div>
  <div class="row m-5">
    <div class="col-lg-3">
      <a href="categories">
        <div class="card" style="width: 15rem;">
          <div class="card-body category">
            <i class="fas fa-shoe-prints fa-3x"></i>
            <p>Shoes</p>
          </div>
        </div>
      </a>
    </div>
    <div class="col-lg-3">
      <a href="categories">
        <div class="card" style="width: 15rem;">
          <div class="card-body category">
            <i class="far fa-clock fa-3x"></i>
            <p>Watch</p>
          </div>
        </div>
      </a>
    </div>
    <div class="col-lg-3">
      <a href="categories">
        <div class="card" style="width: 15rem;">
          <div class="card-body category">
            <i class="fas fa-shirt fa-3x"></i>
            <p>Cloth</p>
          </div>
        </div>
      </a>
    </div>
    <div class="col-lg-3">
      <a href="categories">
        <div class="card" style="width: 15rem;">
          <div class="card-body category">
            <i class="fas fa-book-open fa-3x"></i>
            <p>Book</p>
          </div>
        </div>
      </a>
    </div>
  </div>